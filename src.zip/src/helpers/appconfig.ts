
interface AppConfig{
   appToken: string;
   appUrl: string;   
}

// const appConfig: AppConfig ={
//     appToken:"3fd7a9e80b6c4d129f4afb7a3e2cde5a",
//     appUrl:"https://localhost:7112"
// };

const appConfig: AppConfig ={
    appToken:"3fd7a9e80b6c4d129f4afb7a3e2cde5a",
    appUrl:"https://webappstest.dolgen.net/sohapi"
};
export default appConfig;
