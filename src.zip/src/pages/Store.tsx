import React from 'react'
import Sidebar from "../components/Sidebar";
const Store = () => {
  return (
    <>
    <div>store</div>
   <div className="flex ">    
   <Sidebar />
    </div>
  
   </>
  )
}

export default Store