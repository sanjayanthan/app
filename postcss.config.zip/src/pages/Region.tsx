 import React, { useEffect, useState } from "react";
import Sidebar from "../components/Sidebar";
// import Select from "react-select";
// import axios from "axios";

const Region = () => {
  return (
    <>
     
    <div className="flex ">    
    <Sidebar />
     </div>
   
    </>
  )
}

export default Region